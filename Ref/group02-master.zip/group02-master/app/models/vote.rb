class Vote < ApplicationRecord
	serialize :preferences_converted
public
	# Parses the preference string and stores it into a hash
	def parse_prefs
		prefs = Hash.new
		prefs[:parties], prefs[:candidates] = Candidate.all_parties, []
		prefs[:parties].each do |party|
			Candidate.all.each do |c|
				prefs[:candidates] << c if c.party == party
			end
		end
		prefs[:above], prefs[:below] = [], []
		self.preferences.split(',').each_with_index do |e, i|
			(i < Candidate.all_parties.length) ? (prefs[:above] << e.to_i) : (prefs[:below] << e.to_i)
		end
		return prefs
	end

	# Function that checks if the preference string is invalid
	def check_pref
		above_validity = true
		below_validity = true
		pref_hash = self.parse_prefs
		# ********Checking if empty
		return [false,false] if (pref_hash[:above].length==0 && pref_hash[:below]==0)
		# ********Checking above the line
		one_count = 0
		pref_hash[:above].each do |n|
			one_count+=1 if n==1
		end
		above_validity = false if one_count == 0
		above_validity = false if one_count > 1

		# *******Checking below the line
		stop_num = 6
		stop_num = pref_hash[:candidates].length if pref_hash[:candidates].length < 6
		flag = 0
		(1..pref_hash[:candidates].length).each do |i|
			amount = 0
			pref_hash[:below].each { |n| amount+=1 if n==i }
			if (i<stop_num && (amount > 1 || amount == 0))
				below_validity = false
				break
			end
			flag += 1 if amount == 1
		end
		below_validity = false if (flag < stop_num)

		# Returning
		return [above_validity, below_validity]
	end

	# Function that fixes a valid vote's preferences string where a is above vadility and b is below vadility
	def fix_pref
		pref_hash = self.parse_prefs
		# Fixing above the line
		above = pref_hash[:above]
		(0...pref_hash[:parties].length-above.length).each { above<<0 } if above.length < pref_hash[:parties].length
		# Removing duplicates
		(1..above.length).each do |i|
			amount = 0
			above.each { |e| amount+=1 if i==e }
			above.each_with_index { |e,j| above[j]=0 if e==i} if amount>1
		end
		# Removing numbers larger than any missing numbers
		number_found = false
		for i in 1..above.length
			above.each_with_index do |e, j|
				if above[j] == i
					number_found = true
				end
			end
			if number_found == false
				above.each_with_index do |e, j|
					if e == nil || i < above[j]
						above[j] = 0
					end
				end
			end
			number_found = false
		end

		# Fixing below the line
		below = pref_hash[:below]
		(0...pref_hash[:candidates].length-below.length).each { below<<0 } if below.length < pref_hash[:candidates].length
		# Removing duplicates
		(1..below.length).each do |i|
			amount = 0
			below.each { |e| amount+=1 if i==e }
			below.each_with_index { |e,j| below[j]=0 if e==i} if amount>1
		end
		# Removing numbers larger than any missing numbers
		number_look = 1
		below_flag = false
		below.each_with_index do |e, i| 
			prev = number_look
			below.each { |c| number_look+=1 if c==number_look }
			below_flag = true if number_look == prev
			below[i] = 0 if e==nil || (below_flag == true && e!=0 && e>number_look)
		end

		# Removing sections
        pref_validity = self.check_pref
        if pref_validity[0] && !pref_validity[1]    #If only above the line is valid, delete the below the line votes
            below.fill(0)
        end
        if pref_validity[0] && pref_validity[1]    #If only above the line is valid, delete the below the line votes
            above.fill(0)
        end

		# Updating the preferences string
		new_pref = ''
		above.each { |n| n==0 ? new_pref+=',' : (above.length!=1 ? new_pref+=(n.to_s+',') : new_pref+=n.to_s)  }
		below.each_with_index do |n,i| 
			if n==0 
				i!=(below.length-1) ? new_pref+=',' : new_pref+=''
			else
				i!=(below.length-1) ? new_pref+=(n.to_s+',') : new_pref+=n.to_s
			end
		end
		self.update_attributes(:preferences => new_pref)
	end

	#need all number of candidates for each party	
	def self.parse_num_of_candidates_in_parties
		num_of_candidates_in_parties = []
		(0...Candidate.all_parties.length).each do |i|
			num_of_candidates_in_parties << Candidate.where(party: Candidate.all_parties[i]).length
		end
		return num_of_candidates_in_parties
	end

    #converting the above the lines to below the line votes
    def conversion
        array = Array.new(Candidate.all.length,0)
        id = 1
        next_pref = 1
        assign_done = false
        pref_hash = self.parse_prefs

        #checking if below the line vote
        #if so then return

        pref_validity = self.check_pref
        self.update_attributes(preferences_converted: pref_hash[:below])
        return pref_hash[:below] if ((!pref_validity[0] && pref_validity[1])||(pref_validity[0] && pref_validity[1]))

        (0...pref_hash[:parties].length).each do |i|
            pref_hash[:parties].each_with_index do |party, j|
                if pref_hash[:above][j] == id
                    pref_hash[:candidates].each_with_index do |candidate, k|
                        if candidate.party == party
                            array[k] = next_pref
                            next_pref+=1
                        end
                    end
                    id+=1
                    break
                end
                if j == pref_hash[:parties].length
                    assign_done = true
                    break
                end
            end
            if assign_done
                break
            end
        end
        self.update_attributes(preferences_converted: array)
        return array
    end
end