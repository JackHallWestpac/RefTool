class Candidate < ApplicationRecord
    
    NUM_OF_SENATORS_TO_BE_ELECTED = 2

    def self.all_parties
        Candidate.pluck(:party).uniq
    end

    def get_info
        info = self.surname.upcase+' '+self.given_name+' '+self.party
    end

    def self.elect_senators
        #senators_elected empty array
        senators_elected = []
        #temp counter for debugging
        #counter = 0
        #current surplus value
        current_surplus = 0
        #current target candidate to transfer info too
        current_transfer_target_candidate = 0
        #active_candidates array
        Rails.logger.debug("#{Vote.all[0].parse_prefs[:candidates]}")
        active_candidates = Vote.all[0].parse_prefs[:candidates]
        #calculating senate quota
        quota = (Vote.all.length/(NUM_OF_SENATORS_TO_BE_ELECTED+1))+1
        #final_count array
        final_count = Array.new(Candidate.all.length,0)
        #2d array, containing all the votes for the respected candidate
        candidate_votes = Array.new(Candidate.all.length){Array.new(0)}
        #placing the votes into the 2d array
        Vote.all.each do |v|
           	#converting the vote from below to above the line vote
            v.conversion
            #chucking the vote object into correct candidate's votes array
            candidate_votes[v.preferences_converted.index(1)] << v
            #incrementing that candidates vote count
            final_count[v.preferences_converted.index(1)] += 1
        end

        (0...candidate_votes.length).each do |i|
        	Rails.logger.debug("Candidate: #{active_candidates[i].given_name}")
        	(0...candidate_votes[i].length).each do |k|
        		Rails.logger.debug("Vote: #{candidate_votes[i][k].preferences_converted}")
        	end
        end

        Rails.logger.debug("FINAL COUNT = #{final_count}")

        #return []

        #simulates vote counting
        #checking if a candidate reaches quota
        while senators_elected.length < NUM_OF_SENATORS_TO_BE_ELECTED  do
            #used for the loop to check if senator is elected in that loop
            senator_elected_flag = false
            #going through each unelected candidate
            (0...active_candidates.length).each do |i|
                Rails.logger.debug("current_iteration = #{i}")
                #checking if removed candidate
                if(active_candidates[i]==-1)
                	Rails.logger.debug("already done")
                    next
                end
                #checking if a candidate reaches quota
                if(final_count[i] >= quota)
                	Rails.logger.debug("over quota!")
                    #trigger flag variable
                    senator_elected_flag = true                    
                    #adding current candidate to senators_elected array
                    senators_elected << active_candidates[i]
                    #removing active candidate via assigning -1
                    active_candidates[i]=-1
                    #checking if number of senators needed is met
                    if(senators_elected.length >= NUM_OF_SENATORS_TO_BE_ELECTED)
                    	Rails.logger.debug("done")
                        return senators_elected
                    end
                    #calculating the surplus
                    current_surplus = final_count[i] - quota
                    #if surplus is greater than 0, need to transfer remaining votes
                    if(current_surplus > 0)
                        Rails.logger.debug("surplus")
                    	Rails.logger.debug("current_surplus = #{current_surplus}")
                        #calculating transfer value (useing float)
                        current_transfer_value = current_surplus.to_f/final_count[i]
                        Rails.logger.debug("current_transfer_value = #{current_transfer_value}")
                        #creating a new temp_count array
                        current_next_pref_count = Array.new(active_candidates.length,0)
                        #constructing next pref count array
                        (0...candidate_votes[i].length).each do |v|
                        	Rails.logger.debug("candidate_votes[i].length = #{candidate_votes[i].length}")
                        	Rails.logger.debug("candidate_votes[i] = #{candidate_votes[i]}")
                            #searching for the next candidate that isn't elected
                            (1...final_count.length).each do |c|
		                    	#problems could occur here
		                    	#vote could get scrapped if ran out of preferences!!!????
			                    Rails.logger.debug("candidate_votes[i][v].preferences_converted.index(candidate_votes[i][v].preferences_converted[i]+c) = #{candidate_votes[i][v].preferences_converted.index(candidate_votes[i][v].preferences_converted[i]+c)}")
	                            Rails.logger.debug("candidate_votes[i][v].preferences_converted = #{candidate_votes[i][v].preferences_converted}")
	                            #calculating next candidate to do +1
	                            current_transfer_target_candidate = candidate_votes[i][v].preferences_converted.index(candidate_votes[i][v].preferences_converted[i]+c)
			                    #next target candidate to receive the vote
			                    if(final_count[current_transfer_target_candidate]>=0)
			                    	#found valid target
			                    	Rails.logger.debug("found a valid target")
			                    	break
			                    end
			                end
                            #updating the count of current_next_pref_count by +1
                            current_next_pref_count[current_transfer_target_candidate] += 1
                            #vote transfer - adding vote
                            candidate_votes[current_transfer_target_candidate] << candidate_votes[i][v]
                        end
                        Rails.logger.debug("current_next_pref_count = #{current_next_pref_count}")
                        #transfer votes calculation
                        (0...current_next_pref_count.length).each do |t|
                            final_count[t] += (current_next_pref_count[t] * current_transfer_value).floor
                        	Rails.logger.debug("final_count[t] = #{final_count[t]}")
                        	Rails.logger.debug("current_next_pref_count[t] = #{current_next_pref_count[t]}")
                        end
                    end
                    #making final_count -1 for current Candidate
                    final_count[i] = -1
                end
            end
            #exclusion - no candidate was elected in this loop
            if(senator_elected_flag==false)
            	Rails.logger.debug("exclusion")
                #get candidate with the lowest votes for exclusion
                min_count_candidate = final_count.index(final_count.select{|n| n >= 0}.min)
                Rails.logger.debug("min_count_candidate = #{min_count_candidate}")
                #distribution to other active candidates
                (0...candidate_votes[min_count_candidate].length).each do |v|
                	Rails.logger.debug("candidate_votes[min_count_candidate][v].preferences_converted = #{candidate_votes[min_count_candidate][v].preferences_converted}")
                	Rails.logger.debug("candidate_votes[min_count_candidate].length = #{candidate_votes[min_count_candidate].length}")
                    (1...final_count.length).each do |c|
                    	#problems could occur here
                    	#vote could get scrapped if ran out of preferences!!!????
	                    Rails.logger.debug("candidate_votes[min_count_candidate][v].preferences_converted[min_count_candidate]+c = #{candidate_votes[min_count_candidate][v].preferences_converted[min_count_candidate]+c}")
                    	Rails.logger.debug("candidate_votes[min_count_candidate][v].preferences_converted.index(candidate_votes[min_count_candidate][v].preferences_converted[min_count_candidate]+c) = #{candidate_votes[min_count_candidate][v].preferences_converted.index(candidate_votes[min_count_candidate][v].preferences_converted[min_count_candidate]+c)}")
	                    #next target candidate to receive the vote
	                    current_transfer_target_candidate = candidate_votes[min_count_candidate][v].preferences_converted.index(candidate_votes[min_count_candidate][v].preferences_converted[min_count_candidate]+c)
	                    if(final_count[current_transfer_target_candidate]>=0)
	                    	#found valid target
	                    	Rails.logger.debug("found a valid target")
	                    	break
	                    end
	                end
                    #getting updating the count of current_next_pref_count by +1
                    Rails.logger.debug("current_transfer_target_candidate = #{current_transfer_target_candidate}")
                    final_count[current_transfer_target_candidate] += 1
                    #vote transfer - adding vote
                    candidate_votes[current_transfer_target_candidate] << candidate_votes[min_count_candidate][v]
                end
                #making it -1, as removing candidate from active candidates
                active_candidates[min_count_candidate] = -2
                #making final_count of min_count_candidate needs to become 0
                final_count[min_count_candidate] = -2
            end
            Rails.logger.debug("----------------------------------------------")
            Rails.logger.debug("senator_elected_flag = #{senator_elected_flag}")
            Rails.logger.debug("senators_elected = #{senators_elected}")
            Rails.logger.debug("active_candidates = #{active_candidates}")
            Rails.logger.debug("current_surplus = #{current_surplus}")
            Rails.logger.debug("final_count = #{final_count}")
            Rails.logger.debug("///////////////////////////////////////////////")
	        (0...candidate_votes.length).each do |c|
	        	if(active_candidates[c]==-1 || active_candidates[c]==-2)
	        		#found a already elected or excluded candidate
	        		Rails.logger.debug("found a already elected candidate")
	        		next
	        	else 
	   	        	Rails.logger.debug("Candidate: #{active_candidates[c].given_name}")
		        	(0...candidate_votes[c].length).each do |k|
		        		Rails.logger.debug("Vote: #{candidate_votes[c][k].preferences_converted}")
		        	end
		        end
            end
            Rails.logger.debug("///////////////////////////////////////////////")
            Rails.logger.debug("----------------------------------------------")
            #counter+=1
            #if(counter==1)
            #	return []
            #end
        end
        return senators_elected
    end
end