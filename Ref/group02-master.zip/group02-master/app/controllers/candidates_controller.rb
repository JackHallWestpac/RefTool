class CandidatesController < ApplicationController

	def candidate_params
		params.require(:candidate).permit(:given_name, :surname, :state, :party)
	end

	def new
	end

	def create
		@candidate = Candidate.create!(candidate_params)
		redirect_to candidates_path
	end

	def index
		@candidate = Candidate.all
	end

	def show
    	id = params[:id] # retrieve candidate ID from URI route
    	@candidate = Candidate.find(id) # look up candidate by unique ID
	end

	def edit
		@candidate = Candidate.find params[:id]
	end

	def update
		@candidate = Candidate.find params[:id]
		@candidate.update(candidate_params)
		redirect_to candidate_path(@candidate)
	end

	def destroy
		@candidate = Candidate.find(params[:id])
		@candidate.destroy
		redirect_to candidates_path
	end
end
