class VoteController < ApplicationController
    def vote_params
      	params[:vote][:preferences] = params[:vote].to_unsafe_h.map{|k,v| "#{v}"}.join(',')
        params.require(:vote).permit(:preferences, :preferences_converted)
    end

    def new
    end

    def create
        # render plain: params[:vote].inspect # Debugging - Views params
        @vote = Vote.create!(vote_params)

        # Checking if the user needs to redo their votes
        if @vote.check_pref[0]|@vote.check_pref[1]
        	@vote.fix_pref
        	redirect_to home_index_path
        else
        	@vote.destroy
            flash[:notice] = "The vote preferences were invalid. Please choose 6 parties above the line or 12 candidates below the line"
        	redirect_to new_vote_path
        end

        # redirect_to vote_index_path
    end

    def index
        @vote = Vote.all
    end

    def show
        id = params[:id] # retrieve vote ID from URI route
        @vote = Vote.find(id) # look up vote by unique ID
        @pref_hash = @vote.parse_prefs
    end

    def edit
        @vote = Vote.find params[:id]
    end

    def update
        @vote = Vote.find params[:id]
        @vote.update(vote_params)
        redirect_to vote_path(@vote)
    end

    def destroy
        @vote = Vote.find(params[:id])
        @vote.destroy
        redirect_to vote_index_path
    end
end