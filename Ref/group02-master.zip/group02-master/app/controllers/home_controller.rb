class HomeController < ApplicationController
  def index
  end

  def results
  	@array = Candidate.elect_senators
  end
end
