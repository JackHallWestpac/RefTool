Rails.application.routes.draw do
  get 'home/results'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  # Home Page
  get 'home/index'
  root :to => redirect('/home/index')

  # Results page
  get 'home/results'

  # Candidates
  resources :candidates

  # Vote
  resources :vote

end
