FactoryBot.define do
  factory :candidate do
    surname "MyString"
    given_name "MyString"
    state "MyString"
    party "MyString"
    votes 1
  end
end
