FactoryBot.define do
  factory :vote do
    preferences "MyString"
  end
end
