require 'rails_helper'

RSpec.describe CandidatesController, type: :controller do
end