require 'rails_helper'

RSpec.describe Vote, type: :model do
  before :each do
    @fake_candidates = [FactoryBot.create(:candidate, :party => 'p1', :surname => 'n1'), FactoryBot.create(:candidate, :party => 'p2', :surname => 'n2'), FactoryBot.create(:candidate, :party => 'p3', :surname => 'n3'), FactoryBot.create(:candidate, :party => 'p1', :surname => 'n4'), FactoryBot.create(:candidate, :party => 'p2', :surname => 'n5'), FactoryBot.create(:candidate, :party => 'p3', :surname => 'n6')]
    allow(Candidate).to receive(:all).and_return(@fake_candidates)
    allow(Candidate).to receive(:all_parties).and_return(['p1', 'p2', 'p3'])
    @pref_hash = Hash.new
    @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5]]
  end

  describe 'Testing the parse_prefs function' do
  	before :each do
  		@temp_vote = FactoryBot.create(:vote, :preferences => '1,2,3,1,2,3,4,5,6')
  		@hash = @temp_vote.parse_prefs
  	end
  	it 'returns a hash' do
  		expect(@hash.class).to eq(Hash)
  	end
  	it 'stores the above the line votes in the hash' do
  		expect(@hash[:above]).to eq([1,2,3])
  	end
  	it 'stores the below the line votes in the hash' do
  		expect(@hash[:below]).to eq([1,2,3,4,5,6])
  	end
  	it 'stores the parties in the hash' do
  		expect(@hash[:parties]).to eq(['p1', 'p2', 'p3'])
  	end
  	it 'stores the candidates in the hash and in the correct order' do
  		expect(@hash[:candidates]).to eq([@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5]])
  	end
  end

  describe 'Testing the check_pref function' do
    # Above the line tests
    it 'checks if preferences above the line has at least 1 preferences marked as 1' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [nil,nil,nil,nil,nil,nil]
      pref = ',,,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end
    it 'checks if 1 isnt a repeated number above the line' do
      @pref_hash[:above], @pref_hash[:below] = [1,1,nil], [nil,nil,nil,nil,nil,nil]
      pref = '1,1,,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end
    it 'checks if the one number marked is a one' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,5], [nil,nil,nil,nil,nil,nil]
      pref = ',,5,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end
    it 'passes a valid above the line preference' do
      @pref_hash[:above], @pref_hash[:below] = [1,2,3], [nil,nil,nil,nil,nil,nil]
      pref = '1,2,3,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([true,false])
    end

    # Below the line tests
    it 'checks if preferences below the line has all or at least 6 boxes have been labeled consecutively' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,3,4,5,nil]
      pref = ',,,1,2,3,4,5,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end

    it 'checks if there are no repeated numbers below the line that is less than 6' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,3,4,5,5]
      pref = ',,,1,2,3,4,5,5'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end
    it 'checks if the numbers range between 1 and the number of candidates' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,3,4,5,10]
      pref = ',,,1,2,3,4,5,10'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,false])
    end
    it 'passes a valid above the line preference' do
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,3,4,5,6]
      pref = ',,,1,2,3,4,5,6'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([false,true])
    end
    it 'if the below the line votes is invalid but the above is valid, it uses the above the line votes' do
      @pref_hash[:above], @pref_hash[:below] = [1,2,3], [1,1,1,nil,nil,nil]
      pref = '1,2,3,1,1,1,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.check_pref).to eq([true,false])
    end
  end

  describe 'Testing the fix_pref function on a valid vote' do
    # Above the line
    it 'removes duplicate numbers and numbers higher than the duplicates, above the line' do
      @pref_hash[:above], @pref_hash[:below] = [1,2,2], [nil,nil,nil,nil,nil,nil]
      pref = '1,2,2,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq('1,,,,,,,,')
    end
    it 'removes numbers that are larger than any missing numbers, above the line' do
      @pref_hash[:above], @pref_hash[:below] = [1,3,4], [nil,nil,nil,nil,nil,nil]
      pref = '1,3,4,,,,,,'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq('1,,,,,,,,')
    end
    # Below the line
    it 'removes duplicate numbers and numbers higher than the duplicates, below the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,4,3,6,5,7,7]
      pref = ',,,1,2,4,3,6,5,7,7'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,1,2,4,3,6,5,,')
    end
    it 'removes numbers that are larger than any missing numbers, below the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [nil,nil,nil], [1,2,4,3,6,5,9,8]
      pref = ',,,1,2,4,3,6,5,9,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,1,2,4,3,6,5,,')
    end
    #Testing fix_pref
    it 'removes duplicate numbers, above and below the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [2,1,2], [1,2,4,3,6,5,7,7]
      pref = '2,1,2,1,2,4,3,6,5,7,7'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,1,2,4,3,6,5,,')
    end
    it 'removes numbers that are larger than any missing numbers, above and below the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [1,3,4], [1,2,4,3,5,6,9,8]
      pref = '1,3,4,1,2,4,3,5,6,9,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,1,2,4,3,5,6,,')
    end
    it 'removes duplicate numbers and numbers higher than the duplicates below the line and numbers that are larger than any missing numbers above the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [1,3,3,4], [1,2,4,3,6,5,7,7,8]
      pref = '1,3,3,4,1,2,4,3,6,5,7,7,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,,1,2,4,3,6,5,,,')
    end
    it 'removes below the line preferences if they aren\'t valid and cleans up above the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [3,4,1,5], [1,2,4,3,6,6,9,8]
      pref = '3,4,1,5,1,2,4,3,6,6,9,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,1,,,,,,,,,')
    end
    it 'removes below the line preferences if they aren\'t valid and cleans up above the line (With duplicates)' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [3,4,1,5,3], [1,2,4,3,6,6,9,8]
      pref = '3,4,1,5,3,1,2,4,3,6,6,9,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,1,,,,,,,,,,')
    end
    it 'removes above the line preferences if below the line preferences are valid and cleans up below the line' do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], @fake_candidates[1], @fake_candidates[4], @fake_candidates[2], @fake_candidates[5], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), FactoryBot.create(:candidate, :party => 'p2', :surname => "c8")]
      @pref_hash[:above], @pref_hash[:below] = [3,1,4], [8,1,2,3,4,5,6,8]
      pref = '3,1,4,8,1,2,3,4,5,6,8'
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      vote.fix_pref
      expect(vote.preferences).to eq(',,,,1,2,3,4,5,6,')
    end
  end

  describe 'Testing the conversion function such that it returns the right array' do
    before :each do
      @pref_hash[:parties], @pref_hash[:candidates] = ['p1', 'p2', 'p3'], [@fake_candidates[0], @fake_candidates[3], FactoryBot.create(:candidate, :party => 'p1', :surname => "c7"), @fake_candidates[1], FactoryBot.create(:candidate, :party => 'p2', :surname => "c8"), @fake_candidates[4], @fake_candidates[2], @fake_candidates[5]]
    end
    it 'for a basic preference' do
      pref = '1,2,3,,,,,,,,'
      @pref_hash[:above], @pref_hash[:below] = [1,2,3], [nil,nil,nil,nil,nil,nil,nil,nil]
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.conversion).to eq([1,2,3,4,5,6,7,8])
    end
    it 'for an above the line preference that has gaps (parties with no preferences attached)' do
      pref = '1,,2,,,,,,,,'
      @pref_hash[:above], @pref_hash[:below] = [1,nil,2], [nil,nil,nil,nil,nil,nil,nil,nil]
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.conversion).to eq([1,2,3,0,0,0,4,5])
    end
    it 'a preference that is in a weird order' do
      pref = '3,1,2,,,,,,,,'
      @pref_hash[:above], @pref_hash[:below] = [3,1,2], [nil,nil,nil,nil,nil,nil,nil,nil]
      vote = FactoryBot.create(:vote, :preferences => pref)
      allow(vote).to receive(:parse_prefs).and_return(@pref_hash)
      expect(vote.conversion).to eq([6,7,8,1,2,3,4,5])
    end
  end

end
