require 'rails_helper'

RSpec.describe Candidate, type: :model do
	# Testing the fields in candidates
	it 'Inserting candidate with surname' do
		candidate = Candidate.create(surname: 'Bob')
		expect(candidate.surname).to eq 'Bob'
	end

	it 'Inserting candidate with state' do
		candidate = Candidate.create(state: 'America')
		expect(candidate.state).to eq 'America'
	end

	it 'Inserting candidate with party' do
		candidate = Candidate.create(party: 'Dolphin')
		expect(candidate.party).to eq 'Dolphin'
	end

	it 'Responds to a votes field' do
		candidate = Candidate.new
		expect(candidate).to respond_to(:votes)
	end

	# Testing the functions in the candidates model
	describe 'testing the all_parties function' do
		before :each do
			@fake_candidates = [FactoryBot.create(:candidate), FactoryBot.create(:candidate), FactoryBot.create(:candidate, :party => 'Greens'), FactoryBot.create(:candidate, :party => 'Greens')]
			allow(Candidate).to receive(:all).and_return(@fake_candidates)
			@parties = Candidate.all_parties
		end
		it 'the right amount of parties are returned' do
			expect(@parties.size).to eq(2)
		end
		it 'parties are all unique' do
			expect(@parties).to eq(['MyString', 'Greens'])
		end
		it 'at least one candidate is part of the party' do
			@fake_candidates.each {|c| expect(c.party).to eq('MyString').or eq('Greens')}
		end
	end
end