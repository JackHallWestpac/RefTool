# ESaaS Group Project (Group #02)

Group Members:
  * Harvey Prom         (a1705026)
  * David Harley        (a1688375)
  * Patrick Jenko       (a1705531)
  * Daniel Lukis        (a1706060)
  * Srinivas Sakisbanda (a1704541)

### README

This is a rails-based candidate voting system where you can vote above or below the line, view candidate information and get the current list of candidates with their total number of votes.

### SETUP LOCAL

This project uses ruby 2.5.1. Before running any commands, unzip the file at /lib/seeds/preferences.csv.zip

The commands to run for local development:

+ bundle install --without production

+ rake db:migrate

+ rake db:seed

### SETUP HEROKU

https://group02-18-s1-esas.herokuapp.com
