class RenameNameToGivenName < ActiveRecord::Migration[5.2]
  def change
  	rename_column :candidates, :name, :given_name
  end
end
