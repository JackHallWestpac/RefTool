class AddVotesToCandidates < ActiveRecord::Migration[5.2]
  def change
    add_column :candidates, :votes, :integer
  end
end
