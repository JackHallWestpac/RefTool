class AddPreferencesConvertedToVotes < ActiveRecord::Migration[5.2]
  def change
    add_column :votes, :preferences_converted, :integer, default: [], array: true
  end
end
