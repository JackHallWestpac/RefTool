require 'csv'
require_relative '../app/models/vote.rb'

candidates_csv_text = File.read(Rails.root.join('lib', 'seeds', 'candidates.csv'))
cans_csv = CSV.parse(candidates_csv_text, :headers => true, :encoding => 'ISO-8859-1')

cans_csv.each do |row|
    can = Candidate.new
    can.given_name = row['given_name']
    can.surname = row['surname']
    can.state = row['state']
    can.party = row['party']
    can.save
end

votes_csv_text = File.read(Rails.root.join('lib', 'seeds', 'basic_pref.csv'))
# votes_csv_text = File.read(Rails.root.join('lib', 'seeds', 'preferences.csv'))
votes_csv = CSV.parse(votes_csv_text, :headers => true, :encoding => 'ISO-8859-1')

votes_csv.each_with_index do |row, index|
    vote = Vote.create!( :preferences => row['Preferences'].tr("*", "1").tr("/", "1") ) #Converts all "ticks and crosses" to 1
    # Calling methods on the newly created vote
    if vote.present?
        # Checking if the user needs to redo their votes
        if vote.check_pref[0]|vote.check_pref[1]
            vote.fix_pref
        else
            vote.destroy
        end
    end
end